Dagi ara tafem anasiw n teqbaylit i windows.

## Installation (FRA)

Pour installer le clavier kabyle, veuillez suivre ces étapes:

1. Décompresser (Extraire) le fichier archive "anasiw.zip"
2. Lancer le fichier setup.exe pour installer.
3. Sélectionner la langue "Tamazight" dans votre bar de langue de windows, avec le clavier "Taqbaylit".
4. Utiliser le clavier.


## Installation (ENG)

To install de Latin Kabyle keybord on Windows, please the following steps:

1. Launch the "setup.exe" program to install the keybord.
2. In parameters of the language bar, select your laguage as Tamazight.
3. Choose "Taqbaylit" as a keybord.
4. Enjoy writing Kabyle in latin caracters.
